package sit.int202.simple.simple;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

@WebServlet(name = "FavoriteSubjectServlet", value = "/favoriteSubject")
public class FavoriteSubjectServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doProcess(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doProcess(request, response);
    }

    protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String id = request.getParameter("id");
        String[] favoriteSubject = request.getParameterValues("favorite_subject");

        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1> Your Favorite Subject:: </h1><br>");
        out.println("Student Id = " + id + "<br>");
        out.println("Student Name = " + name + "<br>");
        out.println("Favorite Subject : <br>");
        for (String subject : favoriteSubject) {
            out.println(" &nbsp; &nbsp; - " + subject + "<br>");
        }
        Map<String, String[]> param = request.getParameterMap();
        out.println("<hr>");
        out.println("Request Prameter from Map:: <br>");
        out.println("Student Id = " + param.get("id")[0] + " <br>");
        out.println("Student Name = " + param.get("name")[0] + " <br>");
        out.println("Favorite Subject : <br>");
        for (String subject : param.get("favorite_subject")){
            out.println(" &nbsp; &nbsp; -"+ subject + "<br>");
        }
        out.println("</body></html>");
    }
}
